### Android Training Simples


**不定期更新中...**

 
博客demo 代码合集，详细使用请看对应博客


![目录截图一](image/simple_pic1.png) ![目录截图二](image/simple_pic2.png)


 
### 博客

1, FlexboxLayout Simples
 
[Android可伸缩布局－FlexboxLayout(支持RecyclerView集成)](http://www.jianshu.com/p/3c471953e36d) 




2, SnapHelper Simples

[Android中使用RecyclerView + SnapHelper实现类似ViewPager效果](http://www.jianshu.com/p/ef3a3b8d0a77)

3, Android 底部导航栏 Simples 

[Android 底部导航栏 (底部 Tab) 最佳实践](https://juejin.im/post/5901b564570c35005804424b)
 
 
4,  Android Service和IntentService知识点详细总结

[Android Service和IntentService知识点详细总结](http://www.jianshu.com/p/476d3ed50db1)

5, 仿掌上英雄联盟皮肤浏览效果

[ViewPager系列之－仿掌上英雄联盟皮肤浏览效果](http://www.jianshu.com/p/f1aa52d8f5cc)


### 联系方式
 简书:[http://www.jianshu.com/u/35167a70aa39](http://www.jianshu.com/u/35167a70aa39)
 
 掘金：[https://juejin.im/user/56949a9960b2e058a42be0ba](https://juejin.im/user/56949a9960b2e058a42be0ba)
 
 公众号：**Android技术杂货铺**
 
 欢迎关注我的公众号，第一时间获取我的博客更新提醒，以及更多有价值的原创Android干货文章、职场经验、面试技巧等等。
 长按下方二维码即可关注。

 ![gzh.jpg](image/gzh.jpg)
 