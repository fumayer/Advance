package com.zhouwei.androidtrainingsimples.viewpager_transform;

import android.content.Context;
import android.support.v4.view.ViewPager;

/**
 * Created by zhouwei on 17/5/21.
 */

public class CustomViewPager extends ViewPager {
    public CustomViewPager(Context context) {
        super(context);
    }


}
